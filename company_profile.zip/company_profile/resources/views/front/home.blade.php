@extends('front.layout')
@section('title', 'Beranda')
@section('content')
@include('front.sections.hero')
@include('front.sections.features')
@include('front.sections.products')
@include('front.sections.about')
@include('front.sections.testimonials')
@endsection