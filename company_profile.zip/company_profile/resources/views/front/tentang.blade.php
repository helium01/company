@extends('front.layout')
@section('title', 'Tentang Kami')
@section('content')
<section class="py-5 bg-white">
    <div class="container">
        @include('front.sections.about')
    </div>
</section>
@endsection