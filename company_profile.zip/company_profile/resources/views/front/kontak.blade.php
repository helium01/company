@extends('front.layout')
@section('title', 'Kontak')
@section('content')
<section class="py-5 bg-white">
    <div class="container">
        @include('front.sections.contact')
    </div>
</section>
@endsection