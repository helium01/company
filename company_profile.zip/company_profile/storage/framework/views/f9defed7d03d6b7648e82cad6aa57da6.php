
<?php $__env->startSection('title', 'Kontak'); ?>
<?php $__env->startSection('content'); ?>
<section class="py-5 bg-white">
    <div class="container">
        <?php echo $__env->make('front.sections.contact', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/resources/views/front/kontak.blade.php ENDPATH**/ ?>