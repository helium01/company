

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="mb-4">Daftar Tentang Kami</h1>

    <a href="<?php echo e(route('admin.abouts.create')); ?>" class="btn btn-primary mb-3">Tambah Data</a>

    <?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th width="50">#</th>
                <th>Judul</th>
                <th>Isi</th>
                <th>Gambar</th>
                <th width="200">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $abouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($about->judul); ?></td>
                <td><?php echo e(Str::limit(strip_tags($about->isi), 100)); ?></td>
                <td>
                    <?php if($about->gambar): ?>
                    <img src="<?php echo e(asset('storage/' . $about->gambar)); ?>" width="80">
                    <?php endif; ?>
                </td>
                <td>
                    <a href="<?php echo e(route('admin.abouts.show', $about->id)); ?>" class="btn btn-sm btn-info">Lihat</a>
                    <a href="<?php echo e(route('admin.abouts.edit', $about->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                    <form action="<?php echo e(route('admin.abouts.destroy', $about->id)); ?>" method="POST" class="d-inline"
                        onsubmit="return confirm('Hapus data ini?')">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-sm btn-danger">Hapus</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <?php echo e($abouts->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/resources/views/admin/abouts/index.blade.php ENDPATH**/ ?>