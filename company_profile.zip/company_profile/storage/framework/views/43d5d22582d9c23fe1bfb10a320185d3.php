

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Tambah Kontak</h1>

    <form action="<?php echo e(route('admin.contacts.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="name">Nama</label>
            <input type="text" name="name" class="form-control" id="name">
        </div>
        <div class="mb-3">
            <label for="email">Email</label>
            <input type="email" name="email" class="form-control" id="email">
        </div>
        <div class="mb-3">
            <label for="phone">Telepon</label>
            <input type="text" name="phone" class="form-control" id="phone">
        </div>
        <div class="mb-3">
            <label for="message">Pesan</label>
            <textarea name="message" class="form-control" id="message" rows="5"></textarea>
        </div>
        <button type="submit" class="btn btn-success">Simpan</button>
        <a href="<?php echo e(route('admin.contacts.index')); ?>" class="btn btn-secondary">Kembali</a>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/resources/views/admin/contacts/create.blade.php ENDPATH**/ ?>