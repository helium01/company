

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between mb-3">
    <h3>Produk</h3>
    <a href="<?php echo e(route('admin.products.create')); ?>" class="btn btn-primary">Tambah</a>
</div>

<table class="table table-bordered">
    <thead>
        <tr>
            <th>No</th>
            <th>Gambar</th>
            <th>Nama</th>
            <th>Harga</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($i+1); ?></td>
            <td>
                <?php if($p->gambar): ?>
                <img src="<?php echo e(asset('storage/'.$p->gambar)); ?>" width="60">
                <?php endif; ?>
            </td>
            <td><?php echo e($p->nama); ?></td>
            <td><?php echo e($p->harga); ?></td>
            <td>
                <a href="<?php echo e(route('admin.products.edit', $p)); ?>" class="btn btn-warning btn-sm">Edit</a>
                <form action="<?php echo e(route('admin.products.destroy', $p)); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-danger btn-sm" onclick="return confirm('Hapus produk?')">Hapus</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/resources/views/admin/products/index.blade.php ENDPATH**/ ?>